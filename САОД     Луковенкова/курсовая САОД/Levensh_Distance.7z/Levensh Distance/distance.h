#if !defined(DISTANCE_H)
#define DISTANCE_H
#define min(a, b) (((a) < (b)) ? (a) : (b))

int LD(const char *x, unsigned int m, const char *y, unsigned int n);
int **create_matrix(int Row, int Col);
int _min(int a, int b, int c);

#endif


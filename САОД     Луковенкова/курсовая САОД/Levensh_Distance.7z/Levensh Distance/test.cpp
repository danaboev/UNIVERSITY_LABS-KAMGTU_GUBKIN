#pragma warning(disable:4786)
#include "distance.h"
#include <iostream>
#include <string>
using std::cout;
using std::endl;

int main() {
	std::string text, pattern;
	cout << "\nPlease enter some text: ";
	std::getline(std::cin, text);
	cout << "Enter pattern to search: ";
	std::getline(std::cin, pattern);
	int distance = LD(pattern.c_str(), pattern.length(), text.c_str(), text.length());
	cout << "\nLevenshtein distance(LD) = " << distance << endl;
	return 0;
}